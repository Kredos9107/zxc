from pathlib import Path
import pcbnew as p
import json
R=Path(__file__).parent; D=R/'Vortex_v7_без_перемычек'
src=(R/'decorate_layout.py').read_text(encoding='utf-8')
src=src.replace("D=R/'Vortex_v6_новая_компоновка'","D=R/'Vortex_v7_без_перемычек'")
src=src.replace('ВЕРСИЯ 6','ВЕРСИЯ 7').replace('КОМПОНОВКА 6','КОМПОНОВКА 7')
src=src.replace("text('J5 НАСОС',12,38,.8)","text('J5 НАСОС',12,33,.8)")
start=src.index('for y in [42,55]:')
end=src.index("left=['3V3'",start)
src=src[:start]+'''for f in b.GetFootprints():
 if f.GetReference() in ['J5','J6']:
  names={'1':'CLK','2':'DT','3':'SW','4':'3V3','5':'GND'}
  for pad in f.Pads(): text(names[pad.GetNumber()],7.8,p.ToMM(pad.GetPosition().y),.8)
'''+src[end:]
src=src.replace("'Две перемычки нужны только для питания энкодеров от 3,3 В.'","'ПРОВОДНЫХ ПЕРЕМЫЧЕК НЕТ. Все цепи проложены медью только на B.Cu.',\n+'J5 сверху вниз: GND, 3V3, CLK, DT, SW. J6 сверху вниз: CLK, DT, SW, 3V3, GND.'".replace('\n+','\n'))
src=src.replace("'Все медные дорожки снизу, на B.Cu. Изолированные перемычки — отдельные провода.'","'Все медные дорожки снизу, на B.Cu. Переходных отверстий и верхних дорожек нет.'")
exec(compile(src,'decorate_layout_v7','exec'),{'__file__':str(R/'decorate_layout.py')})
sch=D/(D.name+'.kicad_sch')
sch.write_text(sch.read_text(encoding='utf-8').replace('Vortex_v6_новая_компоновка',D.name),encoding='utf-8')
b=p.LoadBoard(str(D/(D.name+'.kicad_pcb')))
assert all(t.GetLayer()==p.B_Cu and t.GetClass()=='PCB_TRACK' for t in b.GetTracks())
assert not any('ПЕРЕМЫЧКА' in a.GetNetname() for f in b.GetFootprints() for a in f.Pads())
mapping={}
for f in b.GetFootprints():
 if f.GetReference() in ['J5','J6']:
  mapping[f.GetReference()]=[(a.GetNumber(),a.GetNetname(),p.ToMM(a.GetPosition().x),p.ToMM(a.GetPosition().y)) for a in sorted(f.Pads(),key=lambda z:z.GetPosition().y)]
(D/'Порядок_контактов.json').write_text(json.dumps(mapping,ensure_ascii=False,indent=2),encoding='utf-8')
(D/'ПРОЧИТАЙ.txt').write_text('''Версия 7 — односторонняя разводка без проводных перемычек.
Все цепи проложены на B.Cu, без дорожек сверху и без переходных отверстий.
Схема не содержит обходных проводов WP и разделённых ради них цепей.
Вход 12 В и провода насоса припаиваются к плате.
Энкодеры на боковой стенке корпуса, к плате подключаются проводами через J5/J6.
ВАЖНО: у разъёмов разный порядок контактов при виде сверху:
J5 (насос) сверху вниз: GND, 3V3, CLK, DT, SW.
J6 (свет) сверху вниз: CLK, DT, SW, 3V3, GND.
Нумерация контактов сохранена: 1=CLK, 2=DT, 3=SW, 4=3V3, 5=GND.
Перед подключением USB компьютера снять джампер JP1.
Посадки модулей предварительные. Перед изготовлением подтвердить размеры, посадку HW-517 и параметры фрезеровки.
''',encoding='utf-8')
print('Verified: B.Cu only, no vias, no split jumper nets. Track segments:',len(list(b.GetTracks())))
