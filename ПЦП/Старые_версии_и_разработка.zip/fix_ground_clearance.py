from pathlib import Path
import pcbnew as p
D=Path(__file__).parent/'Vortex_v8_доработка'; path=D/(D.name+'.kicad_pcb'); b=p.LoadBoard(str(path))
u=next(f for f in b.GetFootprints() if f.GetReference()=='U1'); z=next(a for a in u.Pads() if a.GetNumber()=='1'); dx=p.ToMM(z.GetPosition().x)-25; dy=p.ToMM(z.GetPosition().y)-32
def point(v): return (round(p.ToMM(v.x)-dx,3),round(p.ToMM(v.y)-dy,3))
def xy(x,y): return p.VECTOR2I(p.FromMM(x+dx),p.FromMM(y+dy))
remove=[((91.5,32),(77,46.5)),((77,46.5),(77,56.25)),((77,56.25),(83.75,63)),((83.75,63),(101,63)),((126.25,32),(128,33.75)),((128,33.75),(128,60.5)),((130,35),(130,32)),((130,35),(130.08,35))]
remove={tuple(sorted(v)) for v in remove}
for t in list(b.GetTracks()):
 if t.GetNetname()=='GND' and tuple(sorted((point(t.GetStart()),point(t.GetEnd())))) in remove: b.Delete(t)
paths=[[(91.5,32),(76,47.5),(76,57.5),(81.5,63),(101,63)],[(126.25,32),(130.08,32),(130.08,35)],[(128,35),(128,60.5)]]
for pts in paths:
 for a,c in zip(pts,pts[1:]):
  t=p.PCB_TRACK(b); t.SetStart(xy(*a)); t.SetEnd(xy(*c)); t.SetWidth(p.FromMM(2)); t.SetLayer(p.B_Cu); t.SetNet(b.FindNet('GND')); b.Add(t)
p.SaveBoard(str(path),b)
