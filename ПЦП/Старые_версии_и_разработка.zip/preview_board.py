from pathlib import Path
import sys,json,os
D=Path(__file__).parent/os.environ.get('VORTEX_PREVIEW_DIR','Vortex_v6_новая_компоновка')
if len(sys.argv)==1:
 import pcbnew as p
 b=p.LoadBoard(str(D/(D.name+'.kicad_pcb')))
 mm=lambda v:[p.ToMM(v.x),p.ToMM(v.y)]
 u=next(f for f in b.GetFootprints() if f.GetReference()=='U1')
 anchor=next(a for a in u.Pads() if a.GetNumber()=='1').GetPosition()
 dx=p.ToMM(anchor.x)-25; dy=p.ToMM(anchor.y)-32
 posmm=lambda v:[p.ToMM(v.x)-dx,p.ToMM(v.y)-dy]
 data={'tracks':[], 'pads':[], 'lines':[], 'texts':[]}
 for t in b.GetTracks(): data['tracks'].append([posmm(t.GetStart()),posmm(t.GetEnd()),p.ToMM(t.GetWidth())])
 for f in b.GetFootprints():
  for a in f.Pads(): data['pads'].append([posmm(a.GetPosition()),mm(a.GetSize()),mm(a.GetDrillSize()),a.GetShape()==p.PAD_SHAPE_RECT])
  for a in f.GraphicalItems():
   if isinstance(a,p.PCB_SHAPE): data['lines'].append([posmm(a.GetStart()),posmm(a.GetEnd())])
 for a in b.GetDrawings():
  if isinstance(a,p.PCB_TEXT):
   pos=posmm(a.GetPosition())
   if pos[0]<145: data['texts'].append([a.GetText(),pos,p.ToMM(a.GetTextSize().y)])
 (D/'preview-data.json').write_text(json.dumps(data,ensure_ascii=False),encoding='utf-8')
else:
 from PIL import Image,ImageDraw,ImageFont
 data=json.loads((D/'preview-data.json').read_text(encoding='utf-8'))
 scale=11; margin=25
 im=Image.new('RGB',(144*scale+2*margin,107*scale+2*margin),'#101c28'); dr=ImageDraw.Draw(im)
 def xy(v): return (round(v[0]*scale)+margin,round(v[1]*scale)+margin)
 dr.rectangle([xy((3,3)),xy((142,104))],fill='#20382f',outline='#5d8c78',width=2)
 for a,c,w in data['tracks']: dr.line([xy(a),xy(c)],fill='#51c991',width=max(1,round(w*scale)))
 for a,c in data['lines']: dr.line([xy(a),xy(c)],fill='#e9cf7c',width=2)
 for v,size,drill,rect in data['pads']:
  x,y=xy(v); rx=size[0]*scale/2; ry=size[1]*scale/2
  bb=(x-rx,y-ry,x+rx,y+ry)
  (dr.rectangle if rect else dr.ellipse)(bb,fill='#db9b64',outline='#eabf91',width=1)
  rr=max(2,drill[0]*scale/2); dr.ellipse((x-rr,y-rr,x+rr,y+rr),fill='#101c28')
 for s,v,h in data['texts']:
  font=ImageFont.truetype(r'C:\Windows\Fonts\arial.ttf',max(8,round(h*scale*1.3)))
  dr.text(xy(v),s,font=font,fill='#fff1c7',anchor='mm')
 im.save(D/'preview.png')
 print(D/'preview.png')
