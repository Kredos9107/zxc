from pathlib import Path
import json, uuid
import pcbnew as p

OUT=Path(__file__).parent/'Vortex_v3_RU'
OUT.mkdir(exist_ok=True)
board=p.BOARD()
def xy(x,y): return p.VECTOR2I(p.FromMM(x),p.FromMM(y))
netnames=['GND','+12V','+5V','ESP_VIN','+3V3','PUMP_POS','PUMP_NEG','PUMP_PWM','LED_GPIO','LED_DATA','ENC1_CLK','ENC1_DT','ENC1_SW','ENC2_CLK','ENC2_DT','ENC2_SW']
nets={}
for name in netnames:
    n=p.NETINFO_ITEM(board,name); board.Add(n); nets[name]=n
parts=[]
def line(container,x1,y1,x2,y2,layer,width=.2):
    s=p.PCB_SHAPE(); s.SetShape(p.SHAPE_T_SEGMENT); s.SetStart(xy(x1,y1)); s.SetEnd(xy(x2,y2)); s.SetLayer(layer); s.SetWidth(p.FromMM(width)); container.Add(s)
def text(t,x,y,size=1,layer=p.F_SilkS):
    if layer==p.F_SilkS: size=max(.8,size)
    a=p.PCB_TEXT(board); a.SetText(t); a.SetPosition(xy(x,y)); a.SetTextSize(xy(size,size)); a.SetTextThickness(p.FromMM(.15)); a.SetLayer(layer); board.Add(a)
def footprint(ref,value,x,y,pins,box=None):
    f=p.FOOTPRINT(board); f.SetReference(ref); f.SetValue(value); f.SetFPID(p.LIB_ID('Vortex',value.replace(' ','_'))); f.SetAttributes(p.FP_THROUGH_HOLE)
    for number,label,net,dx,dy in pins:
        pad=p.PAD(f); pad.SetNumber(str(number)); pad.SetPosition(xy(dx,dy)); pad.SetAttribute(p.PAD_ATTRIB_PTH)
        pad.SetShape(p.PAD_SHAPE_RECT if str(number)=='1' else p.PAD_SHAPE_CIRCLE)
        dia=3.2 if ref in ['J1','J2','J3','U2'] or (ref=='U3' and number<=4) else 1.8
        drill=1.3 if dia==3.2 else 1.0
        pad.SetSize(xy(dia,dia)); pad.SetDrillSize(xy(drill,drill)); pad.SetLayerSet(p.LSET.AllCuMask())
        if net: pad.SetNet(nets[net])
        f.Add(pad)
    if box:
        a,b,c,d=box
        for v in [(a,b,c,b),(c,b,c,d),(c,d,a,d),(a,d,a,b)]: line(f,*v,p.F_SilkS)
    f.Reference().SetVisible(False)
    f.Value().SetVisible(False); f.SetPosition(xy(x,y)); board.Add(f)
    parts.append(dict(ref=ref,value=value,pins=pins,uuid=str(uuid.uuid4())))
    return f

# All positions are top view, USB connector at top of ESP32.
left=['3V3','GND','D15','D2','D4','D16','D17','D5','D18','D19','D21','RX0','TX0','D22','D23']
right=['VIN','GND','D13','D12','D14','D27','D26','D25','D33','D32','D35','D34','VN','VP','EN']
mapping={'3V3':'+3V3','GND':'GND','VIN':'ESP_VIN','D4':'ENC1_CLK','D16':'ENC1_DT','D17':'ENC1_SW','D18':'ENC2_CLK','D19':'ENC2_DT','D21':'ENC2_SW','D23':'LED_GPIO','D25':'PUMP_PWM'}
pins=[]
for row,xx in [(left,0),(right,25.4)]:
    for i,label in enumerate(row): pins.append((len(pins)+1,label,mapping.get(label,''),xx,i*2.54))
footprint('U1','ESP32_30P_SOCKET_PRELIM',55,27,pins,(-2,-7,27.4,44))
for i,label in enumerate(left): text(label,58.5,27+i*2.54,.65)
for i,label in enumerate(right): text(label,76.5,27+i*2.54,.65)
text('ESP32 / USB СВЕРХУ',67.7,21,1)
text('ПЛАТА УПРАВЛЕНИЯ',67.7,66,.9)
footprint('U2','XL4015_SOCKET_20x50_PRELIM',20,25,[(1,'OUT+','+5V',0,0),(2,'OUT-','GND',20,0),(3,'IN+','+12V',0,50),(4,'IN-','GND',20,50)],(-3,-3,23,53))
text('ПРЕОБРАЗОВАТЕЛЬ XL4015',30,16,.9)
text('НАСТРОИТЬ ВЫХОД 5,0 В',30,19,.85)
text('ВЫХОД: +5 В       МИНУС',30,30,.8)
text('ВХОД: +12 В       МИНУС',30,70,.8)
footprint('U3','HW517_FULL_SOCKET_PRELIM',109,30,[(1,'OUT+','PUMP_POS',0,0),(2,'VIN+','+12V',9,0),(3,'OUT-','PUMP_NEG',0,5),(4,'VIN-','GND',9,5),(5,'GND','GND',7.62,31),(6,'TRIG_PWM','PUMP_PWM',0,31)],(-4,-5,13,34))
text('МОСФЕТ HW-517',113,23,1)
text('OUT+',109,27,.8)
text('VIN+',118,27,.8)
text('OUT-',109,38,.8)
text('VIN-',118,38,.8)
text('ВЫХОД НА НАСОС',113,43,.8)
text('OUT+ / OUT-',113,46,.8)
text('ВХОД ПИТАНИЯ',113,50,.8)
text('VIN+ / VIN-',113,53,.8)
text('PWM',109,58,.8)
text('GND',116.62,58,.8)
text('GPIO25 / МИНУС ESP32',113,67,.8)
text('ПОСАДКА УПРАВЛЕНИЯ ПРЕДВАРИТЕЛЬНАЯ',114,70,.6,p.Dwgs_User)
footprint('J1','12V_INPUT_SOLDER',17,90,[(1,'+12V','+12V',0,0),(2,'GND','GND',5.08,0)])
text('J1 ВХОД ПИТАНИЯ: ПАЙКА',20,96,.75)
text('+12 В / МИНУС',20,99,.8)
footprint('J2','PUMP_SOLDER',126,50,[(1,'PUMP+','PUMP_POS',0,0),(2,'PUMP-','PUMP_NEG',5.08,0)])
text('J2 НАСОС: ПАЙКА',129,43,.8)
text('ПЛЮС / МИНУС',129,46,.75)
footprint('J3','WS2811_SOLDER',43,90,[(1,'DATA','LED_DATA',0,0),(2,'+12V','+12V',5.08,0),(3,'GND','GND',10.16,0)])
text('J3 ПОДСВЕТКА: ПАЙКА',48,96,.75)
text('ДАННЫЕ / +12 В / МИНУС',48,99,.7)
footprint('JP1','VIN_POWER_JUMPER',89,25,[(1,'5V','+5V',0,0),(2,'VIN','ESP_VIN',2.54,0)])
text('JP1 ДЖАМПЕР ПИТАНИЯ ESP32',94,13,.7)
text('СНЯТЬ ПЕРЕД USB!',94,16,.85)
text('+5 В / VIN',91,29,.7)
for ref,x,pre in [('J5',76,'ENC1'),('J6',102,'ENC2')]:
    footprint(ref,pre+'_HEADER',x,85,[(1,'CLK',pre+'_CLK',0,0),(2,'DT',pre+'_DT',2.54,0),(3,'SW',pre+'_SW',5.08,0),(4,'3V3','+3V3',7.62,0),(5,'GND','GND',10.16,0)])
    title='ЭНКОДЕР НАСОСА' if ref=='J5' else 'ЭНКОДЕР СВЕТА'
    text(ref+' '+title,x+5,79,.75)
    text('ПРОВОДА К СТЕНКЕ',x+5,82,.7)
    text('CLK DT SW 3V3 GND',x+5,89,.7)
footprint('R1','330R',57,79,[(1,'GPIO23','LED_GPIO',0,0),(2,'DIN','LED_DATA',10.16,0)])
text('РЕЗИСТОР 330 Ом',62,75,.8)
footprint('C1','1000uF_25V',33,86,[(1,'+','+12V',0,0),(2,'-','GND',5,0)])
text('КОНДЕНСАТОР',33,81,.75)
text('1000 мкФ: + / -',33,83,.65)
footprint('D1','1N5819',120,72,[(1,'K_STRIPE','PUMP_POS',0,0),(2,'A','PUMP_NEG',10.16,0)])
text('ДИОД 1N5819',124,76,.8)
text('ПОЛОСА СЛЕВА: OUT+',124,79,.65)
for x,y in [(8,8),(137,8),(8,99),(137,99)]:
    f=p.FOOTPRINT(board); f.SetReference('H'); pad=p.PAD(f); pad.SetAttribute(p.PAD_ATTRIB_NPTH); pad.SetShape(p.PAD_SHAPE_CIRCLE); pad.SetSize(xy(3.2,3.2)); pad.SetDrillSize(xy(3.2,3.2)); pad.SetLayerSet(p.LSET.AllCuMask()); f.Add(pad); f.SetPosition(xy(x,y)); f.Reference().SetVisible(False); f.Value().SetVisible(False); board.Add(f)
for v in [(3,3,142,3),(142,3,142,104),(142,104,3,104),(3,104,3,3)]: line(board,*v,p.Edge_Cuts)
text('ВОДЯНОЙ ВИХРЬ — ВИД СВЕРХУ — ЧЕРНОВИК БЕЗ ДОРОЖЕК',73,7,.9)
text('РАЗМЕРЫ ПОСАДОК ПРОВЕРИТЬ. ДЛЯ ИЗГОТОВЛЕНИЯ НЕ ГОТОВО.',73,102,.75,p.Dwgs_User)
legend=[
 'КАК ЧИТАТЬ ЭТУ ПЛАТУ',
 'Красные площадки с отверстиями — места пайки или установки гнёзд.',
 'Тонкие линии — будущие соединения. Медные дорожки ещё не разведены.',
 'Жёлтые контуры — предварительные границы модулей. Вид сверху.',
 '',
 'СЛЕВА: XL4015, преобразует 12 В в 5 В для ESP32.',
 'Установить модуль в гнёзда. До установки настроить выход на 5,0 В.',
 'ПО ЦЕНТРУ: ESP32, два гнезда по 15 контактов. USB сверху.',
 'ДЖАМПЕР: соединяет 5 В преобразователя с VIN ESP32.',
 'Перед подключением USB компьютера обязательно снять джампер.',
 '',
 'СПРАВА: HW-517, регулирует насос по сигналу ESP32 GPIO25.',
 'Четыре силовых контакта сверху, управление на другом конце модуля.',
 'Управление включено в общую посадку HW-517. Отдельного J4 нет.',
 'Силовые контакты: верхний ряд OUT+ / VIN+; нижний ряд OUT- / VIN-.',
 'OUT+ идёт только к плюсу насоса и катоду диода; с VIN+ на нашей плате не соединён.',
 'VIN- и GND управления соединены с GND ESP32 общей цепью GND.',
 'OUT- — управляемый минус насоса; напрямую с GND он не соединяется.',
 'Голубые линии выбирают ближайшие контакты общей цепи, это не дорожки.',
 'Расположение двух используемых контактов управления предварительное.',
 'Дополнительные площадки на фото пока не перенесены без проверки.',
 '',
 'ВХОД ПИТАНИЯ: блок 12 В → внешняя клемма → провода → пайка в J1.',
 'J1: контакт 1 = +12 В, контакт 2 = общий минус.',
 'НАСОС: провода припаять в J2; 1 = плюс, 2 = минус через мосфет.',
 'ПОДСВЕТКА J3: 1 = данные через 330 Ом, 2 = +12 В, 3 = минус.',
 '',
 'ЭНКОДЕРЫ СТОЯТ В СТЕНКЕ КОРПУСА. На плате только разъёмы проводов.',
 'J5 — насос: вращение меняет скорость; нажатие включает/выключает.',
 'J6 — свет: нажатие выбирает цвет или яркость; вращение регулирует.',
 'Порядок контактов J5/J6 слева направо: CLK, DT, SW, 3V3, GND.',
 'CLK/DT — вращение; SW — нажатие; 3V3 — питание 3,3 В; GND — минус.',
 'GPIO насоса: 25. Подсветки: 23. J5: 4/16/17. J6: 18/19/21.',
 '',
 'КОНДЕНСАТОР: плюс в +12 В, минус в общий минус.',
 'ДИОД: вывод с полосой к плюсу насоса; другой — к минусу насоса.',
 'РЕЗИСТОР: 330 Ом между GPIO23 и проводом данных подсветки.',
 '',
 'Пока не паять: проверить реальные посадки модулей и параметры фрезеровки.'
]
for i,s in enumerate(legend):
    if s: text(s,215,10+i*3,1.05 if i==0 else .85,p.Dwgs_User)
(OUT/'Что_где_на_плате.txt').write_text('\n'.join(legend),encoding='utf-8')
p.SaveBoard(str(OUT/'Vortex_v3_RU.kicad_pcb'),board)
(OUT/'Vortex_v3_RU.kicad_pro').write_text(json.dumps({'meta':{'filename':'Vortex_v3_RU.kicad_pro','version':1}},indent=2))

# Self-contained schematic; each module is represented by a named pin block.
def q(s): return json.dumps(str(s),ensure_ascii=False)
def uid(): return str(uuid.uuid4())
root=uid(); libs=[]; instances=[]; wires=[]; labels=[]
libdir=OUT/'Vortex.pretty'; libdir.mkdir(exist_ok=True)
for f in board.GetFootprints():
    match=next((a for a in parts if a['ref']==f.GetReference()),None)
    if match:
        f.SetPath(p.KIID_PATH('/'+root+'/'+match['uuid']))
        p.PCB_IO_MGR.FindPlugin(p.PCB_IO_MGR.KICAD_SEXP).FootprintSave(str(libdir),f)
p.SaveBoard(str(OUT/'Vortex_v3_RU.kicad_pcb'),board)
(OUT/'fp-lib-table').write_text('(fp_lib_table (version 7) (lib (name "Vortex")(type "KiCad")(uri "${KIPRJMOD}/Vortex.pretty")(options "")(descr "Project module sockets - preliminary")))',encoding='utf-8')
positions={'U1':(25,30),'U2':(25,130),'U3':(120,30),'J1':(210,30),'J2':(210,58),'J3':(210,86),'JP1':(120,65),'J5':(120,100),'J6':(210,120),'R1':(25,165),'C1':(120,150),'D1':(210,165)}
russian={'U1':'ESP32 — плата управления','U2':'XL4015 — питание 5 В','U3':'HW-517 — управление насосом','J1':'Вход 12 В — пайка проводов','J2':'Насос — пайка проводов','J3':'Подсветка — провода','JP1':'Джампер VIN — снять перед USB','J5':'Провода энкодера насоса','J6':'Провода энкодера света','R1':'Резистор 330 Ом','C1':'Конденсатор 1000 мкФ 25 В','D1':'Диод 1N5819'}
for part in parts:
    x,y=positions[part['ref']]
    ref=part['ref']; ps=part['pins']; name='Vortex:'+ref; h=max(7.62,(len(ps)+1)*2.54)
    plist=[]
    for i,(num,label,net,dx,dy) in enumerate(ps):
        yy=-(i+1)*2.54
        plist.append(f'(pin passive line (at 30.48 {yy} 180) (length 5.08) (name {q(label)} (effects (font (size 1 1)))) (number {q(num)} (effects (font (size 1 1)))))')
        if net:
            wy=y-yy
            wires.append(f'(wire (pts (xy {x+30.48} {wy}) (xy {x+35.56} {wy})) (stroke (width 0) (type default)) (uuid {uid()}))')
            labels.append(f'(label {q(net)} (at {x+35.56} {wy} 0) (effects (font (size 1 1)) (justify left bottom)) (uuid {uid()}))')
    libs.append(f'(symbol {q(name)} (pin_names (offset 0.508)) (in_bom yes) (on_board yes) (property "Reference" {q(ref)} (at 0 2.54 0) (effects (font (size 1 1)))) (property "Value" {q(part["value"])} (at 0 5.08 0) (effects (font (size 1 1)))) (symbol {q(ref+"_0_1")} (rectangle (start 0 0) (end 25.4 {-h}) (stroke (width .254) (type default)) (fill (type background)))) (symbol {q(ref+"_1_1")} {" ".join(plist)}))')
    pininst=' '.join(f'(pin {q(z[0])} (uuid {uid()}))' for z in ps)
    instances.append(f'(symbol (lib_id {q(name)}) (at {x} {y} 0) (unit 1) (in_bom yes) (on_board yes) (dnp no) (uuid {part["uuid"]}) (property "Reference" {q(ref)} (at {x+12.7} {y-5.08} 0) (effects (font (size 1.27 1.27)))) (property "Value" {q(part["value"])} (at {x+12.7} {y-2.54} 0) (effects (font (size .9 .9)))) {pininst} (instances (project "Vortex_v3_RU" (path "/{root}" (reference {q(ref)}) (unit 1)))))')
for i,part in enumerate(parts):
    fpname='Vortex:'+part['value'].replace(' ','_')
    instances[i]=instances[i].replace(' (instances (project',f' (property "Footprint" {q(fpname)} (at 0 0 0) (effects (font (size 1 1)) hide)) (instances (project')
    instances[i]=instances[i].replace(q(part['value']),q(russian[part['ref']]))
sch=f'(kicad_sch (version 20250114) (generator "eeschema") (uuid {root}) (paper "A4") (lib_symbols {" ".join(libs)}) {" ".join(wires+labels+instances)} (embedded_fonts no))'
(OUT/'Vortex_v3_RU.kicad_sch').write_text(sch,encoding='utf-8')
(OUT/'connections.json').write_text(json.dumps(parts,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'ПРОЧИТАЙ.md').write_text('''# Vortex v2 — черновик размещения, не для изготовления

Создано 01.11.2026. Схема и плата с электрическими связями; дорожки ещё не проложены.
Основа: пожелания пользователя и фотографии модулей. Старый файл Claude не восстановлен.

Вход питания: внешний DC-разъём с клеммами → два провода → пайка в J1.
Насос: пайка проводов в J2. Лента: J3 (предварительно пайка).
JP1: 5 В XL4015 → VIN ESP32. Снимать перед подключением USB компьютера.
Общая земля. Энкодеры только 3,3 В. XL4015 до установки настроить на 5,0 В.

ESP32: два гнезда по 15 контактов, шаг 2,54 мм, междурядье предварительно 25,4 мм.
Распиновка ESP32 по типу платы с фото, подлежит сверке маркировки перед изготовлением.
XL4015: предварительно 20 × 50 мм между центрами силовых контактов по разметке фото снизу.
HW-517: силовые контакты предварительно 9 × 5 мм; габарит и точная геометрия управления не подтверждены.
J4 удалён. Два используемых контакта управления включены в U3 на другом конце модуля.
Координаты управления предварительные: от силового ряда до управления около 31 мм (5 + 26).
Фото снизу отражено: силовой вход VIN справа при виде сверху, выход OUT слева.
На фото есть дополнительные сигнальные площадки; их назначение и геометрия не проверены, они пока не включены.
Установка HW-517 на силовые ножки требует доступа к контактным отверстиям: способ установки пока не подтверждён.
Модули размещены сверху; посадки учитывают зеркальность фотографий снизу.
Площадка под C1 и остальные корпуса компонентов предварительные, сверить с реальными деталями.
Габарит платы 139 × 101 мм предварительный, корпус подгоняется позже.
Энкодеры крепятся в боковой стенке корпуса; J5/J6 — разъёмы проводов к ним.
Справа от платы на слое Dwgs.User размещена подробная русская памятка.
Не выпускать Gerber/G-code до сверки замеров, способа установки и возможностей фрезеровки.

GPIO25 — насос. GPIO23 — подсветка через R1 330 Ом.
Энкодер 1: CLK=4, DT=16, SW=17; вращение — скорость, нажатие — насос вкл/выкл.
Энкодер 2: CLK=18, DT=19, SW=21; нажатие переключает цвет/яркость, вращение меняет значение.
Это назначение платы; существующая прошивка ещё не обновлена.
Режимы эффектов подсветки остаются в веб-интерфейсе.

Перед завершением: проверить размеры всех посадок и ориентацию, распечатать 1:1,
узнать заготовку и фрезу, выполнить трассировку B.Cu и DRC.
''',encoding='utf-8')
print(OUT)
print('Footprints:',len(list(board.GetFootprints())),'nets:',len(nets),'tracks:',len(list(board.GetTracks())))
