from pathlib import Path
import pcbnew as p
import math,shutil,json
D=Path(__file__).parent/'Vortex_v8_доработка'; path=D/(D.name+'.kicad_pcb')
shutil.copy2(path,D/'до_чистки_петель.kicad_pcb')
b=p.LoadBoard(str(path))
def remaining():
 b.BuildConnectivity(); b.GetConnectivity().RecalculateRatsnest(); return b.GetConnectivity().GetUnconnectedCount(False)
assert remaining()==0
def spec(t): return (t.GetNetname(),t.GetStart().x,t.GetStart().y,t.GetEnd().x,t.GetEnd().y,t.GetWidth(),t.GetLayer())
def length(s): return math.hypot(s[3]-s[1],s[4]-s[2])
def add(s):
 n,x,y,u,v,w,layer=s; t=p.PCB_TRACK(b); t.SetStart(p.VECTOR2I(x,y)); t.SetEnd(p.VECTOR2I(u,v)); t.SetWidth(w); t.SetLayer(layer); t.SetNet(b.FindNet(n)); b.Add(t)
removed=[]
specs=sorted((spec(t) for t in b.GetTracks() if t.GetNetname() not in ['PUMP_POS','PUMP_NEG']),key=length,reverse=True)
for s in specs:
 if length(s)<p.FromMM(.75): continue
 t=next((t for t in b.GetTracks() if spec(t)==s),None)
 if t is None: continue
 b.Delete(t)
 if remaining()==0: removed.append(s)
 else: add(s)
assert remaining()==0
p.SaveBoard(str(path),b)
(D/'removed-redundant-tracks.json').write_text(json.dumps(removed,ensure_ascii=False,indent=2),encoding='utf-8')
print('Removed redundant segments:',len(removed),'remaining:',len(list(b.GetTracks())),flush=True)
