from pathlib import Path
import pcbnew as p
import shutil, subprocess, json, math, sys
ROOT=Path(__file__).parent
SOURCE=ROOT/'Vortex_v3_RU'
exe=r'C:\Program Files\KiCad\10.0\bin\python.exe'
configs={
 'A':{'U1':(25,32,0),'U2':(65,17,90),'U3':(95,55,0),'J1':(125,35,0),'J2':(80,55,0),'J3':(22,90,0),'JP1':(52,32,0),'J5':(12,42,90),'J6':(12,57,90),'R1':(22,79,0),'C1':(125,45,0),'D1':(80,47,0)},
 'B':{'U1':(35,58,90),'U2':(15,15,0),'U3':(105,35,0),'J1':(55,15,0),'J2':(125,40,90),'J3':(85,90,0),'JP1':(40,35,90),'J5':(44,94,0),'J6':(62,94,0),'R1':(78,80,90),'C1':(65,15,0),'D1':(125,55,90)},
 'C':{'U1':(35,48,90),'U2':(15,15,0),'U3':(105,35,0),'J1':(55,15,0),'J2':(125,40,90),'J3':(85,88,0),'JP1':(40,32,90),'J5':(44,85,0),'J6':(62,85,0),'R1':(78,76,90),'C1':(65,15,0),'D1':(125,55,90)},
 'D':{'U1':(35,48,90),'U2':(65,15,90),'U3':(105,48,0),'J1':(125,25,90),'J2':(125,55,90),'J3':(18,80,90),'JP1':(45,30,0),'J5':(44,86,0),'J6':(62,86,0),'R1':(25,76,90),'C1':(120,15,0),'D1':(125,70,90)}
}
def xy(x,y): return p.VECTOR2I(p.FromMM(x),p.FromMM(y))
def text(b,s,x,y,size=.9,layer=p.F_SilkS):
    a=p.PCB_TEXT(b); a.SetText(s); a.SetPosition(xy(x,y)); a.SetTextSize(xy(size,size)); a.SetTextThickness(p.FromMM(.15)); a.SetLayer(layer); b.Add(a)
def build(name,cfg):
    d=ROOT/('_layout_'+name); d.mkdir(exist_ok=True)
    b=p.LoadBoard(str(SOURCE/'до_разводки.kicad_pcb'))
    print('Preparing layout',name,flush=True)
    for obj in list(b.GetDrawings()):
        if isinstance(obj,p.PCB_TEXT): b.Delete(obj)
    for f in list(b.GetFootprints()):
        ref=f.GetReference()
        if ref not in cfg: continue
        print('Place',ref,flush=True)
        xx,yy,angle=cfg[ref]; f.SetOrientationDegrees(angle)
        ps=list(f.Pads()); ax=min(p.ToMM(v.GetPosition().x) for v in ps); ay=min(p.ToMM(v.GetPosition().y) for v in ps)
        f.Move(xy(xx-ax,yy-ay))
    text(b,'ВОДЯНОЙ ВИХРЬ — КОМПОНОВКА '+name+' — ВИД СВЕРХУ',72,7,1)
    text(b,'ПОСАДКИ МОДУЛЕЙ ПРЕДВАРИТЕЛЬНЫЕ',72,102,.85,p.Dwgs_User)
    print('Saving layout',name,flush=True)
    p.SaveBoard(str(d/'до_разводки.kicad_pcb'),b)
    shutil.copy2(SOURCE/'схема_до_перемычек.kicad_sch',d/(d.name+'.kicad_sch'))
    shutil.copy2(SOURCE/'connections.json',d/'connections.json')
    shutil.copy2(SOURCE/'Vortex_v3_RU.kicad_pro',d/(d.name+'.kicad_pro'))
    subprocess.run([exe,str(ROOT/'route_vortex.py'),str(d)],check=True)
    status=json.loads((d/'routing-status.json').read_text())
    b=p.LoadBoard(str(d/(d.name+'.kicad_pcb')))
    length=sum(math.dist((p.ToMM(t.GetStart().x),p.ToMM(t.GetStart().y)),(p.ToMM(t.GetEnd().x),p.ToMM(t.GetEnd().y))) for t in b.GetTracks())
    power={'GND','+12V','PUMP_POS','PUMP_NEG'}
    bad=sum(z[0] in power for z in status['missing'])
    return {'variant':name,'links':len(status['missing']),'missing_power':bad,'length_mm':round(length),'segments':len(list(b.GetTracks()))}
configs['E']=dict(configs['A'],J5=(12,42,270),J6=(12,54,270))
scores=[]
for name,cfg in configs.items():
    if len(sys.argv)>1 and name!=sys.argv[1]: continue
    r=build(name,cfg); scores.append(r); print('LAYOUT',r,flush=True)
    (ROOT/'layout-comparison.json').write_text(json.dumps(scores,indent=2),encoding='utf-8')
