from pathlib import Path
import pcbnew as p
import json, re, uuid, math, shutil, sys
D=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).parent/'Vortex_v3_RU'
bp=D/(D.name+'.kicad_pcb'); sp=D/(D.name+'.kicad_sch')
shutil.copy2(sp,D/'схема_до_перемычек.kicad_sch')
b=p.LoadBoard(str(bp)); c=b.GetConnectivity()
def key(a): return a.m_Uuid.AsString()
items=[a for f in b.GetFootprints() for a in f.Pads() if a.GetNetname()]+list(b.GetTracks())
parent={key(a):key(a) for a in items}; bykey={key(a):a for a in items}
def root(k):
    while parent[k]!=k: parent[k]=parent[parent[k]]; k=parent[k]
    return k
for a in items:
    for z in c.GetConnectedItems(a):
        if key(z) in parent and z.GetNetname()==a.GetNetname(): parent[root(key(z))]=root(key(a))
groups={}
for a in items: groups.setdefault(a.GetNetname(),{}).setdefault(root(key(a)),[]).append(a)
changes={}; links=[]
def pos(a): return (p.ToMM(a.GetPosition().x),p.ToMM(a.GetPosition().y))
def ispad(a): return a.GetClass()=='PAD'
for n,islands in groups.items():
    islands=[v for v in islands.values() if any(ispad(z) for z in v)]
    islands.sort(key=lambda v:-sum(ispad(z) for z in v))
    if len(islands)<2: continue
    assigned=[]
    for i,objects in enumerate(islands):
        new=n if i==0 else n+'_ПЕРЕМЫЧКА_'+str(i)
        if i:
            net=p.NETINFO_ITEM(b,new); b.Add(net)
            for a in objects: a.SetNet(net)
        gp=[a for a in objects if ispad(a)]
        for a in gp: changes[(a.GetParentFootprint().GetReference(),a.GetNumber())]=new
        if assigned:
            aa,zz=min(((aa,zz) for aa in assigned for zz in gp),key=lambda az:math.dist(pos(az[0]),pos(az[1])))
            links.append({'ref':'WP'+str(len(links)+1),'net_a':aa.GetNetname(),'net_b':zz.GetNetname(),'a':[aa.GetParentFootprint().GetReference(),aa.GetNumber()],'b':[zz.GetParentFootprint().GetReference(),zz.GetNumber()],'pa':pos(aa),'pb':pos(zz),'original_net':n})
        assigned+=gp

class Atom(str): pass
def parse(src):
    ts=re.findall(r'"(?:\\.|[^"\\])*"|[()]|[^\s()]+',src); i=0
    def read():
        nonlocal i
        t=ts[i]; i+=1
        if t=='(':
            out=[]
            while ts[i]!=')': out.append(read())
            i+=1; return out
        return json.loads(t) if t.startswith('"') else Atom(t)
    return read()
def dump(v):
    if isinstance(v,list): return '('+' '.join(dump(x) for x in v)+')'
    return str(v) if isinstance(v,Atom) else json.dumps(v,ensure_ascii=False)
def child(o,k): return next((x for x in o if isinstance(x,list) and x and x[0]==k),None)
def U(): return str(uuid.uuid4())
sch=parse(sp.read_text(encoding='utf-8'))
child(sch,'paper')[1]='A3'
parts=json.loads((D/'connections.json').read_text(encoding='utf-8'))
partmap={a['ref']:a for a in parts}
labelmap={}
for s in sch:
    if not isinstance(s,list) or not s or s[0]!='symbol': continue
    ref=next(z[2] for z in s if isinstance(z,list) and z[:2]==['property','Reference'])
    a=child(s,'at'); x=float(a[1]); y=float(a[2])
    for i,pin in enumerate(partmap[ref]['pins']):
        new=changes.get((ref,str(pin[0])))
        if new: labelmap[(round(x+35.56,3),round(y+(i+1)*2.54,3))]=new
for s in sch:
    if isinstance(s,list) and s and s[0]=='label':
        a=child(s,'at'); new=labelmap.get((round(float(a[1]),3),round(float(a[2]),3)))
        if new: s[1]=new
rid=child(sch,'uuid')[1]
lib=child(sch,'lib_symbols')
q=lambda s:json.dumps(str(s),ensure_ascii=False)
for i,w in enumerate(links):
    ref=w['ref']; name='Vortex:'+ref; x=300+(i//6)*60; y=30+(i%6)*35
    lib.append(parse(f'''(symbol {q(name)} (in_bom yes) (on_board no)
      (property "Reference" {q(ref)} (at 0 2.54 0) (effects (font (size 1 1))))
      (property "Value" "Изолированный провод" (at 0 5.08 0) (effects (font (size 1 1))))
      (symbol "{ref}_0_1" (rectangle (start 0 0) (end 25.4 -7.62) (stroke (width .254) (type default)) (fill (type background))))
      (symbol "{ref}_1_1"
        (pin passive line (at 30.48 -2.54 180) (length 5.08) (name "Начало" (effects (font (size 1 1)))) (number "1" (effects (font (size 1 1)))))
        (pin passive line (at 30.48 -5.08 180) (length 5.08) (name "Конец" (effects (font (size 1 1)))) (number "2" (effects (font (size 1 1)))))))'''))
    sch.append(parse(f'''(symbol (lib_id {q(name)}) (at {x} {y} 0) (unit 1) (in_bom yes) (on_board no) (dnp no) (uuid {U()})
      (property "Reference" {q(ref)} (at {x+12.7} {y-5.08} 0) (effects (font (size 1 1))))
      (property "Value" "Изолированный провод" (at {x+12.7} {y-2.54} 0) (effects (font (size .8 .8))))
      (pin "1" (uuid {U()})) (pin "2" (uuid {U()}))
      (instances (project "Vortex_v3_RU" (path "/{rid}" (reference {q(ref)}) (unit 1)))))'''))
    for k,net in enumerate([w['net_a'],w['net_b']]):
        yy=y+(k+1)*2.54
        sch.append(parse(f'(wire (pts (xy {x+30.48} {yy}) (xy {x+35.56} {yy})) (stroke (width 0) (type default)) (uuid {U()}))'))
        sch.append(parse(f'(label {q(net)} (at {x+35.56} {yy} 0) (effects (font (size .8 .8)) (justify left bottom)) (uuid {U()}))'))
    for suffix,point in [('A',w['pa']),('B',w['pb'])]:
        t=p.PCB_TEXT(b); t.SetText(ref+':'+suffix); t.SetPosition(p.VECTOR2I(p.FromMM(point[0]),p.FromMM(point[1]-2))); t.SetTextSize(p.VECTOR2I(p.FromMM(.9),p.FromMM(.9))); t.SetTextThickness(p.FromMM(.15)); t.SetLayer(p.Dwgs_User); b.Add(t)
    t=p.PCB_TEXT(b); t.SetText(f"{ref}: {w['a'][0]} контакт {w['a'][1]} -> {w['b'][0]} контакт {w['b'][1]} — изолированный провод"); t.SetPosition(p.VECTOR2I(p.FromMM(215),p.FromMM(135+i*3))); t.SetTextSize(p.VECTOR2I(p.FromMM(.85),p.FromMM(.85))); t.SetTextThickness(p.FromMM(.15)); t.SetLayer(p.Dwgs_User); b.Add(t)
p.SaveBoard(str(bp),b); sp.write_text(dump(sch),encoding='utf-8')
(D/'wire-links.json').write_text(json.dumps(links,ensure_ascii=False,indent=2),encoding='utf-8')
lines=['ПРОВОДНЫЕ ПЕРЕМЫЧКИ: ИЗОЛИРОВАННЫЙ ПРОВОД, НЕ МЕДЬ ВТОРОГО СЛОЯ.','Дорожки только снизу B.Cu. Перемычки припаиваются к указанным существующим контактам.','Провода цепей 12 В/насоса — 0,5–0,75 мм²; сигнальные 3,3 В — 0,25–0,35 мм².','Геометрию и доступ к пайке проверить после установки гнёзд модулей.','']
for w in links: lines.append(f"{w['ref']}: {w['a'][0]} контакт {w['a'][1]} <-> {w['b'][0]} контакт {w['b'][1]} ({w['original_net']}).")
(D/'Перемычки.txt').write_text('\n'.join(lines),encoding='utf-8')
print('Wire links:',len(links),'split islands:',len(changes))
