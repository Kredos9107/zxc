from pathlib import Path
import subprocess,json,shutil,math
import pcbnew as p
R=Path(__file__).parent; exe=r'C:\Program Files\KiCad\10.0\bin\python.exe'
signals=['ENC1_CLK','ENC1_DT','ENC1_SW','ENC2_CLK','ENC2_DT','ENC2_SW','PUMP_PWM','LED_GPIO','LED_DATA']
power=['+12V','PUMP_POS','PUMP_NEG','GND','+5V','ESP_VIN','+3V3']
orders=[['+5V','ESP_VIN']+power[:4]+['+3V3']+signals,
        ['+5V','ESP_VIN']+signals+power[:4]+['+3V3'],
        ['+5V','ESP_VIN','+12V','PUMP_POS','PUMP_NEG']+signals+['GND','+3V3'],
        ['+5V','ESP_VIN','+12V','PUMP_POS','PUMP_NEG','+3V3']+signals+['GND'],
        signals+power,
        ['+5V','ESP_VIN','GND']+signals+['+12V','PUMP_POS','PUMP_NEG','+3V3']]
orders=[orders[1],orders[2]]
best=None; scores=[]
for name in ['A','E']:
 d=R/('_layout_'+name)
 for i,order in enumerate(orders):
    subprocess.run([exe,str(R/'route_vortex.py'),str(d),','.join(order)],check=True,stdout=subprocess.DEVNULL)
    st=json.loads((d/'routing-status.json').read_text()); missing=st['missing']
    b=p.LoadBoard(str(d/(d.name+'.kicad_pcb')))
    le=sum(math.hypot(p.ToMM(t.GetEnd().x-t.GetStart().x),p.ToMM(t.GetEnd().y-t.GetStart().y)) for t in b.GetTracks())
    critical=sum(v[0] in ['+12V','PUMP_POS','PUMP_NEG'] for v in missing)
    score=(critical,len(missing),le)
    item={'layout':name,'order':i,'links':len(missing),'critical':critical,'length':round(le),'score':score}
    scores.append(item); print(item,flush=True)
    if best is None or score<best['score']:
        best=item; target=R/'Vortex_v6_новая_компоновка'; target.mkdir(exist_ok=True)
        shutil.copy2(d/(d.name+'.kicad_pcb'),target/(target.name+'.kicad_pcb'))
        shutil.copy2(d/(d.name+'.kicad_sch'),target/(target.name+'.kicad_sch'))
        shutil.copy2(d/(d.name+'.kicad_pro'),target/(target.name+'.kicad_pro'))
        shutil.copy2(d/'connections.json',target/'connections.json')
        shutil.copy2(d/'routing-status.json',target/'routing-status.json')
        (target/'layout-result.json').write_text(json.dumps(item,indent=2),encoding='utf-8')
    (R/'route-layout-results.json').write_text(json.dumps(scores,indent=2),encoding='utf-8')
print('BEST',best,flush=True)
