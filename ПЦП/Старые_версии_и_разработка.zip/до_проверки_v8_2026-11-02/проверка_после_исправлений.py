from pathlib import Path
from collections import defaultdict,deque
import os,json,pcbnew as p,xml.etree.ElementTree as E
D=Path(os.environ['TEMP'])/'pcp-v8-review-20261102';b=p.LoadBoard(str(D/'Vortex_v8_доработка.kicad_pcb'))
actual=defaultdict(set);pos={}
for f in b.GetFootprints():
 for a in f.Pads():
  if a.GetNetname():actual[a.GetNetname()].add((f.GetReference(),a.GetNumber()))
  pos[f.GetReference(),a.GetNumber()]=(round(p.ToMM(a.GetPosition().x),3),round(p.ToMM(a.GetPosition().y),3))
schematic={n.get('name'):{(v.get('ref'),v.get('pin')) for v in n.findall('node')} for n in E.parse(D/'verified.xml').findall('./nets/net')}
assert dict(actual)==schematic,(dict(actual),schematic)
expected={
 '/+12V':{('J1','1'),('U2','3'),('U3','2'),('J3','2'),('C1','1')},
 '/+5V':{('U2','1'),('JP1','1')}, '/ESP_VIN':{('JP1','2'),('U1','16')},
 '/+3V3':{('U1','1'),('J5','4'),('J6','4')},
 '/GND':{('J1','2'),('U2','2'),('U2','4'),('U3','4'),('U3','5'),('U1','2'),('U1','17'),('J3','3'),('C1','2'),('J5','5'),('J6','5')},
 '/PUMP_POS':{('U3','1'),('J2','1'),('D1','1')}, '/PUMP_NEG':{('U3','3'),('J2','2'),('D1','2')},
 '/PUMP_PWM':{('U1','23'),('U3','6')}, '/LED_GPIO':{('U1','15'),('R1','1')},'/LED_DATA':{('R1','2'),('J3','1')},
 '/ENC1_CLK':{('U1','5'),('J5','1')},'/ENC1_DT':{('U1','6'),('J5','2')},'/ENC1_SW':{('U1','7'),('J5','3')},
 '/ENC2_CLK':{('U1','9'),('J6','1')},'/ENC2_DT':{('U1','10'),('J6','2')},'/ENC2_SW':{('U1','11'),('J6','3')},
}
assert {n:v for n,v in actual.items() if not n.startswith('unconnected-')}==expected
assert all(t.GetClass()=='PCB_TRACK' and t.GetLayer()==p.B_Cu for t in b.GetTracks())
# Prove a continuous 2 mm route for each power load without relying on the modules' internal ground connections.
def path(net,start,end,width=2):
 g=defaultdict(set)
 for t in b.GetTracks():
  if t.GetNetname()!=net or p.ToMM(t.GetWidth())<width-1e-6:continue
  a=(round(p.ToMM(t.GetStart().x),3),round(p.ToMM(t.GetStart().y),3));c=(round(p.ToMM(t.GetEnd().x),3),round(p.ToMM(t.GetEnd().y),3));g[a].add(c);g[c].add(a)
 q=deque([pos[start]]);seen={pos[start]}
 while q:
  a=q.popleft()
  for c in g[a]:
   if c not in seen:seen.add(c);q.append(c)
 assert pos[end] in seen,(net,start,end)
checks=[('/+12V',('J1','1'),('U3','2')),('/+12V',('J1','1'),('U2','3')),('/+12V',('J1','1'),('J3','2')),('/+12V',('J1','1'),('C1','1')),('/GND',('J1','2'),('U3','4')),('/GND',('J1','2'),('J3','3')),('/GND',('J1','2'),('C1','2')),('/PUMP_POS',('U3','1'),('J2','1')),('/PUMP_POS',('U3','1'),('D1','1')),('/PUMP_NEG',('U3','3'),('J2','2')),('/PUMP_NEG',('U3','3'),('D1','2'))]
for args in checks:path(*args)
for net in ('/+5V','/ESP_VIN'):
 assert all(p.ToMM(t.GetWidth())>=1-1e-6 for t in b.GetTracks() if t.GetNetname()==net)
assert not any(t.GetNetname().startswith('unconnected-') for t in b.GetTracks())
for f in b.GetFootprints():
 if f.GetReference()=='U1':
  for a in f.Pads():
   if a.GetNetname().startswith('unconnected-'):assert len(actual[a.GetNetname()])==1
box=b.GetBoardEdgesBoundingBox()
print(json.dumps({'functional_nets':len(expected),'intentionally_unused_pins':len(actual)-len(expected),'power_paths_2mm':len(checks),'single_copper_layer':'B.Cu','board_mm':[round(p.ToMM(box.GetWidth()),2),round(p.ToMM(box.GetHeight()),2)],'result':'PASS'},ensure_ascii=False,indent=2))
