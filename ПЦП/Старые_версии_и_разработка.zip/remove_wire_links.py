from pathlib import Path
import pcbnew as p
import subprocess,json,shutil,math
R=Path(__file__).parent; exe=r'C:\Program Files\KiCad\10.0\bin\python.exe'
src=R/'_layout_E'/'до_разводки.kicad_pcb'
signals=['ENC1_CLK','ENC1_DT','ENC1_SW','ENC2_CLK','ENC2_DT','ENC2_SW','PUMP_PWM','LED_GPIO','LED_DATA']
power=['+12V','PUMP_POS','PUMP_NEG','GND']
orders=[['+5V','ESP_VIN']+signals+power+['+3V3'],
        ['+5V','ESP_VIN','+3V3']+signals+power,
        ['+3V3']+signals+['+5V','ESP_VIN']+power]
perms=[
(['4','1','2','3','5'],['1','2','3','4','5'],39.62,54),
(['4','1','2','3','5'],['1','2','3','5','4'],39.62,54),
(['5','4','1','2','3'],['1','2','3','4','5'],37.08,52.32),
(['5','4','1','2','3'],['1','2','3','5','4'],37.08,52.32),
(['4','5','1','2','3'],['1','2','3','5','4'],37.08,52.32),
(['5','1','2','3','4'],['4','1','2','3','5'],39.62,52),
(['4','1','2','3','5'],['5','1','2','3','4'],39.62,52),
(['1','2','3','5','4'],['4','5','1','2','3'],42.16,54),
]
best=99
for i,(o1,o2,y1,y2) in enumerate(perms):
 d=R/('_zero_'+str(i)); d.mkdir(exist_ok=True)
 b=p.LoadBoard(str(src))
 for f in b.GetFootprints():
  ref=f.GetReference()
  if ref not in ['J5','J6']: continue
  order,top=(o1,y1) if ref=='J5' else (o2,y2)
  for pad in f.Pads():
   j=order.index(pad.GetNumber()); pad.SetPosition(p.VECTOR2I(p.FromMM(12),p.FromMM(top+j*2.54)))
 p.SaveBoard(str(d/'до_разводки.kicad_pcb'),b)
 for k,order in enumerate(orders):
  subprocess.run([exe,str(R/'route_vortex.py'),str(d),','.join(order)],check=True,stdout=subprocess.DEVNULL)
  st=json.loads((d/'routing-status.json').read_text()); count=len(st['missing'])
  print('Layout',i,'order',k,'missing',count,st['missing'],flush=True)
  if count<best:
   best=count; target=R/'Vortex_v7_без_перемычек'; target.mkdir(exist_ok=True)
   shutil.copy2(d/(d.name+'.kicad_pcb'),target/(target.name+'.kicad_pcb'))
   shutil.copy2(R/'Vortex_v6_новая_компоновка'/'схема_до_перемычек.kicad_sch',target/(target.name+'.kicad_sch'))
   shutil.copy2(R/'Vortex_v6_новая_компоновка'/'Vortex_v6_новая_компоновка.kicad_pro',target/(target.name+'.kicad_pro'))
   shutil.copy2(R/'Vortex_v6_новая_компоновка'/'connections.json',target/'connections.json')
   shutil.copy2(d/'routing-status.json',target/'routing-status.json')
   (target/'connector-order.json').write_text(json.dumps({'J5':o1,'J6':o2,'y1':y1,'y2':y2,'layout':i,'routing_order':k,'missing':st['missing']},indent=2),encoding='utf-8')
  if count==0: print('ZERO WIRE LINKS FOUND',flush=True); raise SystemExit(0)
print('BEST REMAINING',best,flush=True)
