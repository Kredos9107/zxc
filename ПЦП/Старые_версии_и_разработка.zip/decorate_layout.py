from pathlib import Path
import pcbnew as p
import json, shutil
R=Path(__file__).parent; D=R/'Vortex_v6_новая_компоновка'; path=D/(D.name+'.kicad_pcb')
b=p.LoadBoard(str(path))
def xy(x,y): return p.VECTOR2I(p.FromMM(x),p.FromMM(y))
def text(s,x,y,size=.8,layer=p.F_SilkS):
    t=p.PCB_TEXT(b); t.SetText(s); t.SetPosition(xy(x,y)); t.SetTextSize(xy(size,size)); t.SetTextThickness(p.FromMM(.15)); t.SetLayer(layer); b.Add(t)
for d in list(b.GetDrawings()):
    if isinstance(d,p.PCB_TEXT): b.Delete(d)
text('ВОДЯНОЙ ВИХРЬ — ВЕРСИЯ 6 — ВИД СВЕРХУ',73,7,1)
text('ESP32 / USB СВЕРХУ',37.7,22,.85)
text('ДВА ГНЕЗДА ПО 15',37.7,73,.8)
text('ПРЕОБРАЗОВАТЕЛЬ XL4015',90,11,.85)
text('НАСТРОИТЬ ВЫХОД 5,0 В',90,25,.85)
text('OUT- / МИНУС',72,20,.8)
text('OUT+ / 5 В',72,34,.8)
text('IN- / МИНУС',107,20,.8)
text('IN+ / 12 В',107,34,.8)
text('JP1',57.3,21,.85)
text('5 В / VIN',57.3,29,.8)
text('J1 ВХОД 12 В',126,30,.8)
text('+12 В / МИНУС',127.5,39,.8)
text('ПАЙКА ПРОВОДОВ',127.5,42,.8)
text('C1 1000 мкФ',127.5,50,.8)
text('ПЛЮС / МИНУС',127.5,53,.8)
text('МОСФЕТ HW-517',99.5,47,.85)
text('OUT+',95,52,.8); text('VIN+',104,52,.8)
text('OUT-',95,63,.8); text('VIN-',104,63,.8)
text('К НАСОСУ',99.5,68,.8)
text('OUT+ / OUT-',99.5,71,.8)
text('ВХОД 12 В',99.5,76,.8)
text('VIN+ / VIN-',99.5,79,.8)
text('PWM',95,91,.8); text('GND',102.62,91,.8)
text('J2 НАСОС',82.5,51,.8)
text('ПЛЮС / МИНУС',82.5,59,.8)
text('D1 1N5819',85,43,.8)
text('ПОЛОСА СЛЕВА',85,49,.8,p.Dwgs_User)
text('R1 330 Ом',27,82,.8)
text('J3 ПОДСВЕТКА',27,85,.8)
text('ДАННЫЕ / 12 В / МИНУС',27,94,.8)
text('J5 НАСОС',12,38,.8)
text('J6 СВЕТ',12,69,.8)
for y in [42,55]:
    for i,s in enumerate(['CLK','DT','SW','3V3','GND']): text(s,7.8,y+i*2.54,.8)
left=['3V3','GND','D15','D2','D4','D16','D17','D5','D18','D19','D21','RX0','TX0','D22','D23']
right=['VIN','GND','D13','D12','D14','D27','D26','D25','D33','D32','D35','D34','VN','VP','EN']
for i,s in enumerate(left): text(s,28.5,32+i*2.54,.8)
for i,s in enumerate(right): text(s,46.5,32+i*2.54,.8)
text('ПОСАДКИ МОДУЛЕЙ ПРЕДВАРИТЕЛЬНЫЕ. ПЕРЕД ИЗГОТОВЛЕНИЕМ ПРОВЕРИТЬ.',73,102,.8,p.Dwgs_User)
notes=['КОМПОНОВКА 6: ЧТО ГДЕ',
'Сверху: преобразователь XL4015, установлен поперёк платы. Выход настроить на 5 В.',
'Справа сверху: J1, пайка двух проводов от внешнего разъёма блока питания 12 В.',
'По центру слева: ESP32, USB сверху. Рядом JP1 — джампер питания VIN.',
'ПЕРЕД ПОДКЛЮЧЕНИЕМ USB КОМПЬЮТЕРА СНЯТЬ JP1.',
'Слева: J5/J6 — только разъёмы проводов. Энкодеры стоят в боковой стенке корпуса.',
'J5: нажатие включает насос, вращение меняет скорость.',
'J6: нажатие выбирает цвет/яркость, вращение меняет выбранное значение.',
'Под ESP32: J3 — провода подсветки; над ним резистор R1 330 Ом.',
'Справа: HW-517 и J2, пайка двух проводов насоса. Рядом защитный диод D1.',
'VIN мосфета — вход питания, OUT — выход к насосу. Они не объединены на нашей плате.',
'Все медные дорожки снизу, на B.Cu. Изолированные перемычки — отдельные провода.',
'Две перемычки нужны только для питания энкодеров от 3,3 В.',
'Красные площадки — места пайки/гнёзд; зелёные дорожки — медь снизу.',
'Размеры посадок и монтаж мосфета пока предварительные. Размер заготовки/фреза не известны.']
for i,s in enumerate(notes): text(s,220,12+i*3,1 if i==0 else .85,p.Dwgs_User)
(D/'Что_где_на_плате.txt').write_text('\n'.join(notes),encoding='utf-8')
p.SaveBoard(str(path),b)
schpath=D/(D.name+'.kicad_sch')
schpath.write_text(schpath.read_text(encoding='utf-8').replace('"Vortex_v3_RU"','"'+D.name+'"'),encoding='utf-8')
shutil.copytree(R/'Vortex_v3_RU'/'Vortex.pretty',D/'Vortex.pretty',dirs_exist_ok=True)
shutil.copy2(R/'Vortex_v3_RU'/'fp-lib-table',D/'fp-lib-table')
print(path)
