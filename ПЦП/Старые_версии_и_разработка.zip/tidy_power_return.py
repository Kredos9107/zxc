from pathlib import Path
import pcbnew as p
import math,json
D=Path(__file__).parent/'Vortex_v8_доработка'; path=D/(D.name+'.kicad_pcb'); b=p.LoadBoard(str(path))
u=next(f for f in b.GetFootprints() if f.GetReference()=='U1'); a=next(a for a in u.Pads() if a.GetNumber()=='1')
dx=p.ToMM(a.GetPosition().x)-25; dy=p.ToMM(a.GetPosition().y)-32
def keypos(v): return (round(p.ToMM(v.x)-dx,3),round(p.ToMM(v.y)-dy,3))
def xy(x,y): return p.VECTOR2I(p.FromMM(x+dx),p.FromMM(y+dy))
seen=set(); removed=0
for t in list(b.GetTracks()):
 key=(t.GetNetname(),tuple(sorted((tuple(t.GetStart()),tuple(t.GetEnd())))),t.GetWidth(),t.GetLayer())
 if key in seen: b.Delete(t); removed+=1
 else: seen.add(key)
main=[((91.5,32),(126.25,32)),((126.25,32),(128,33.75)),((128,33.75),(128,60.5)),((91.5,32),(77,46.5)),((77,46.5),(77,56.25)),((77,56.25),(83.75,63)),((83.75,63),(101,63)),((101,63),(104,60))]
main={tuple(sorted(z)) for z in main}; widened=0
for t in b.GetTracks():
 if t.GetNetname()=='GND' and tuple(sorted((keypos(t.GetStart()),keypos(t.GetEnd())))) in main:
  t.SetWidth(p.FromMM(2)); widened+=1
t=p.PCB_TRACK(b); t.SetStart(xy(130.08,35)); t.SetEnd(xy(128,35)); t.SetWidth(p.FromMM(2)); t.SetLayer(p.B_Cu); t.SetNet(b.FindNet('GND')); b.Add(t)
b.BuildConnectivity(); b.GetConnectivity().RecalculateRatsnest(); assert b.GetConnectivity().GetUnconnectedCount(False)==0
p.SaveBoard(str(path),b)
print('Duplicate segments removed:',removed,'power return segments widened to 2 mm:',widened)
