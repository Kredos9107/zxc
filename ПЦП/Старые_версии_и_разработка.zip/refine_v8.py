from pathlib import Path
import pcbnew as p
import json,shutil,subprocess,os,math
R=Path(__file__).parent; S=R/'Vortex_v7_без_перемычек'; D=R/'Vortex_v8_доработка'; D.mkdir(exist_ok=True)
exe=r'C:\Program Files\KiCad\10.0\bin\python.exe'
src=S/(S.name+'.kicad_pcb'); original=p.LoadBoard(str(src))
u1=next(f for f in original.GetFootprints() if f.GetReference()=='U1')
u1p=next(a for a in u1.Pads() if a.GetNumber()=='1')
dx=p.ToMM(u1p.GetPosition().x)-25; dy=p.ToMM(u1p.GetPosition().y)-32
def xy(x,y): return p.VECTOR2I(p.FromMM(x),p.FromMM(y))
for f in original.GetFootprints(): f.Move(xy(-dx,-dy))
for t in list(original.GetTracks()): original.Delete(t)
for a in original.GetDrawings(): a.Move(xy(-dx,-dy))
for a in original.GetDrawings():
 if isinstance(a,p.PCB_TEXT) and 'ВЕРСИЯ 7' in a.GetText(): a.SetText(a.GetText().replace('ВЕРСИЯ 7','ВЕРСИЯ 8'))
def addtrack(b,n,pts,w=2):
 for a,c in zip(pts,pts[1:]):
  t=p.PCB_TRACK(b); t.SetStart(xy(*a)); t.SetEnd(xy(*c)); t.SetWidth(p.FromMM(w)); t.SetLayer(p.B_Cu); t.SetNet(b.FindNet(n)); b.Add(t)
addtrack(original,'PUMP_POS',[(80,47),(80,50.5),(80,55)])
addtrack(original,'PUMP_POS',[(80,50.5),(90.5,50.5),(95,55)])
addtrack(original,'PUMP_NEG',[(85.08,55),(90.08,60),(95,60)])
addtrack(original,'PUMP_NEG',[(90.16,47),(96,47),(100,51),(100,56),(96,60),(95,60)])
base=D/'база_без_петель.kicad_pcb'; p.SaveBoard(str(base),original)
signals=['ENC1_CLK','ENC1_DT','ENC1_SW','ENC2_CLK','ENC2_DT','ENC2_SW','PUMP_PWM','LED_GPIO','LED_DATA']
orders=[['+5V','ESP_VIN','+3V3']+signals+['+12V','GND'],['+5V','ESP_VIN','+3V3','+12V']+signals+['GND'],['+3V3']+signals+['+5V','ESP_VIN','+12V','GND'],['+5V','ESP_VIN','+3V3','GND']+signals+['+12V']]
best=None; final=None
for ci,(cx,cy) in enumerate([(43,90),(44,92),(42,85),(46,88)]):
 b=p.LoadBoard(str(base))
 cap=next(f for f in b.GetFootprints() if f.GetReference()=='C1')
 pp=next(a for a in cap.Pads() if a.GetNumber()=='1'); oldx=p.ToMM(pp.GetPosition().x); oldy=p.ToMM(pp.GetPosition().y)
 cap.Move(xy(cx-oldx,cy-oldy))
 for a in b.GetDrawings():
  if isinstance(a,p.PCB_TEXT):
   pos=a.GetPosition(); tx=p.ToMM(pos.x); ty=p.ToMM(pos.y)
   if abs(tx-127.5)<.1 and (a.GetText()=='C1 1000 мкФ' or a.GetText()=='ПЛЮС / МИНУС'): a.Move(xy(cx-oldx,cy-oldy))
 p.SaveBoard(str(D/'до_разводки.kicad_pcb'),b)
 for oi,order in enumerate(orders):
  env=dict(os.environ,VORTEX_FIXED_NETS='PUMP_POS,PUMP_NEG')
  subprocess.run([exe,str(R/'route_vortex.py'),str(D),','.join(order)],check=True,env=env,stdout=subprocess.DEVNULL)
  status=json.loads((D/'routing-status.json').read_text(encoding='utf-8'))
  count=len(status['missing']); routed=p.LoadBoard(str(D/(D.name+'.kicad_pcb')))
  length=sum(math.hypot(p.ToMM(t.GetEnd().x-t.GetStart().x),p.ToMM(t.GetEnd().y-t.GetStart().y)) for t in routed.GetTracks())
  score=(count,length)
  print('Cap',cx,cy,'order',oi,'missing',count,status['missing'],flush=True)
  if best is None or score<best:
   best=score; final=D/'выбранная_разводка.kicad_pcb'; shutil.copy2(D/(D.name+'.kicad_pcb'),final)
   (D/'refinement.json').write_text(json.dumps({'source':str(src),'source_offset':[dx,dy],'capacitor_position':[cx,cy],'missing':status['missing'],'length_mm':length,'order':oi},ensure_ascii=False,indent=2),encoding='utf-8')
  if count==0: break
 if count==0: break
assert best and best[0]==0,'No complete single layer routing found yet'
b=p.LoadBoard(str(final))
for f in b.GetFootprints(): f.Move(xy(dx,dy))
for t in b.GetTracks(): t.Move(xy(dx,dy))
for a in b.GetDrawings(): a.Move(xy(dx,dy))
p.SaveBoard(str(D/(D.name+'.kicad_pcb')),b)
for suffix in ['.kicad_pro','.kicad_sch']:
 content=(S/(S.name+suffix)).read_text(encoding='utf-8').replace(S.name,D.name)
 (D/(D.name+suffix)).write_text(content,encoding='utf-8')
shutil.copytree(S/'Vortex.pretty',D/'Vortex.pretty',dirs_exist_ok=True)
for name in ['fp-lib-table','connections.json','ПРОЧИТАЙ.txt']: shutil.copy2(S/name,D/name)
print('FINAL',D,'preserved user offset',dx,dy,flush=True)
