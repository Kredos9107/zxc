from pathlib import Path
import pcbnew as p
import numpy as np
import heapq, math, time, json, shutil, sys, os

D=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).parent/'Vortex_v3_RU'
path=D/(D.name+'.kicad_pcb')
backup=D/'до_разводки.kicad_pcb'
if not backup.exists(): shutil.copy2(path,backup)
b=p.LoadBoard(str(backup))
S=.25; NX=581; NY=429
X=np.arange(NX)*S; Y=np.arange(NY)*S
pads=[]; groups={}
for f in b.GetFootprints():
    for pad in f.Pads():
        pos=pad.GetPosition(); sz=pad.GetSize()
        item=(p.ToMM(pos.x),p.ToMM(pos.y),p.ToMM(sz.x)/2,p.ToMM(sz.y)/2,pad.GetNetname(),f.GetReference(),pad.GetNumber())
        pads.append(item)
        if item[4]: groups.setdefault(item[4],[]).append(item)
def idx(a): return (round(a[0]/S),round(a[1]/S))
def paint(mask,x,y,r):
    xa=max(0,int((x-r)/S)); xb=min(NX-1,int((x+r)/S)+1)
    ya=max(0,int((y-r)/S)); yb=min(NY-1,int((y+r)/S)+1)
    mask[ya:yb+1,xa:xb+1] |= (X[xa:xb+1][None,:]-x)**2+(Y[ya:yb+1][:,None]-y)**2 <= r*r
def astar(start,end,blocked,deadline):
    sx,sy=start; ex,ey=end
    if blocked[sy,sx] or blocked[ey,ex]: return None
    def h(x,y):
        dx=abs(x-ex); dy=abs(y-ey)
        return max(dx,dy)+.41421356*min(dx,dy)
    queue=[(h(sx,sy),0,sx,sy)]; costs={start:0}; prev={}; counter=0
    while queue:
        _,g,x,y=heapq.heappop(queue)
        if g>costs.get((x,y),1e30): continue
        if (x,y)==end:
            route=[end]
            while route[-1]!=start: route.append(prev[route[-1]])
            return route[::-1]
        counter+=1
        if counter%10000==0 and time.time()>deadline: return None
        for dx,dy in [(1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)]:
            xx=x+dx; yy=y+dy
            if xx<0 or yy<0 or xx>=NX or yy>=NY or blocked[yy,xx]: continue
            if dx and dy and (blocked[y,xx] or blocked[yy,x]): continue
            turn=0
            old=prev.get((x,y))
            if old and (x-old[0],y-old[1])!=(dx,dy): turn=.8
            gg=g+(1.41421356 if dx and dy else 1)+turn
            if gg>=costs.get((xx,yy),1e30): continue
            costs[xx,yy]=gg; prev[xx,yy]=(x,y); heapq.heappush(queue,(gg+h(xx,yy),gg,xx,yy))
    return None
def width(n): return 2.0 if n in ['+12V','PUMP_POS','PUMP_NEG'] else 1.0 if n in ['GND','+5V','ESP_VIN'] else .6
def compact(points):
    if len(points)<3: return points
    out=[points[0]]
    for i in range(1,len(points)-1):
        a=out[-1]; c=points[i+1]; v=points[i]
        if abs((v[0]-a[0])*(c[1]-v[1])-(v[1]-a[1])*(c[0]-v[0]))>1e-8: out.append(v)
    return out+[points[-1]]
def attempt(order,timeout=45):
    traces=seed_traces[:]; missing=[]; deadline=time.time()+timeout
    for n in order:
        if n in fixed_nets: continue
        w=width(n); blocked=np.zeros((NY,NX),dtype=bool)
        blocked[:22,:]=True; blocked[405:,:]=True; blocked[:,:22]=True; blocked[:,558:]=True
        for x,y,rx,ry,pn,ref,num in pads:
            if pn!=n: paint(blocked,x,y,max(rx,ry)+.5+w/2+.2)
        for tn,tw,pts in traces:
            if tn==n: continue
            r=tw/2+w/2+.5+.2
            for a,c in zip(pts,pts[1:]):
                length=math.dist(a,c); k=max(1,math.ceil(length/.3))
                for i in range(k+1): paint(blocked,a[0]+(c[0]-a[0])*i/k,a[1]+(c[1]-a[1])*i/k,r)
        gp=groups[n]; connected=[gp[0]]; remain=gp[1:]
        while remain:
            a,c=min(((a,c) for a in connected for c in remain),key=lambda z:math.dist(z[0][:2],z[1][:2]))
            result=astar(idx(a),idx(c),blocked,deadline)
            if result:
                points=compact([a[:2]]+[(x*S,y*S) for x,y in result]+[c[:2]])
                traces.append((n,w,points))
            else: missing.append((n,a[5:7],c[5:7]))
            connected.append(c); remain.remove(c)
    return traces,missing
priority=['+12V','PUMP_POS','PUMP_NEG','GND','+5V','ESP_VIN','+3V3']
fixed_nets=set(os.environ.get('VORTEX_FIXED_NETS','').split(','))-{''}
seed_traces=[(t.GetNetname(),p.ToMM(t.GetWidth()),[(p.ToMM(t.GetStart().x),p.ToMM(t.GetStart().y)),(p.ToMM(t.GetEnd().x),p.ToMM(t.GetEnd().y))]) for t in b.GetTracks() if t.GetNetname() in fixed_nets]
if len(sys.argv)>2: priority=sys.argv[2].split(',')
base=sorted(groups,key=lambda n:(priority.index(n) if n in priority else 10,-len(groups[n])))
best=None
for trial in range(1):
    if trial==0: order=base
    elif trial==1: order=list(reversed(base))
    else:
        import random
        order=base[:]; random.Random(30+trial).shuffle(order)
    result=attempt(order)
    print('Attempt',trial+1,'connections',len(result[0]),'missing',len(result[1]),flush=True)
    if best is None or len(result[1])<len(best[1]): best=result
    if not result[1]: break
for t in list(b.GetTracks()): b.Delete(t)
for n,w,points in best[0]:
    net=b.FindNet(n)
    for a,c in zip(points,points[1:]):
        if math.dist(a,c)<.001: continue
        t=p.PCB_TRACK(b); t.SetStart(p.VECTOR2I(p.FromMM(a[0]),p.FromMM(a[1]))); t.SetEnd(p.VECTOR2I(p.FromMM(c[0]),p.FromMM(c[1]))); t.SetWidth(p.FromMM(w)); t.SetLayer(p.B_Cu); t.SetNet(net); b.Add(t)
for d in b.GetDrawings():
    if isinstance(d,p.PCB_TEXT):
        s=d.GetText()
        if 'ЧЕРНОВИК БЕЗ ДОРОЖЕК' in s: d.SetText(s.replace('ЧЕРНОВИК БЕЗ ДОРОЖЕК','ЧЕРНОВИК РАЗВОДКИ'))
        if 'Медные дорожки ещё не разведены.' in s: d.SetText('Медные дорожки снизу, слой B.Cu. Остаток соединений см. отчёт проверки.')
p.SaveBoard(str(path),b)
(D/'routing-status.json').write_text(json.dumps({'routed_connections':len(best[0]),'missing':best[1],'layer':'B.Cu','widths_mm':{n:width(n) for n in groups}},ensure_ascii=False,indent=2),encoding='utf-8')
print('Saved',path,'missing:',best[1],flush=True)
