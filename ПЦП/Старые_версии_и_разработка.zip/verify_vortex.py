from pathlib import Path
import xml.etree.ElementTree as ET
import pcbnew as p
import sys
d=Path(__file__).parent/(sys.argv[1] if len(sys.argv)>1 else 'Vortex_v2')
b=p.LoadBoard(str(d/(d.name+'.kicad_pcb')))
actual={}
for f in b.GetFootprints():
    for pad in f.Pads():
        n=pad.GetNetname()
        if n: actual.setdefault(n,set()).add((f.GetReference(),pad.GetNumber()))
sch={n.attrib['name'].lstrip('/'): {(v.attrib['ref'],v.attrib['pin']) for v in n.findall('node') if not v.attrib['ref'].startswith('WP')} for n in ET.parse(d/'verified.xml').findall('./nets/net')}
for name,pins in actual.items():
    assert pins==sch.get(name), (name,pins,sch.get(name))
print('Verified: all',len(actual),'connected schematic nets match board pads.')
if (d/'wire-links.json').exists():
    import json
    links=json.loads((d/'wire-links.json').read_text(encoding='utf-8'))
    netroot={n:n for n in actual}
    def root(n):
        while netroot[n]!=n: n=netroot[n]
        return n
    for w in links: netroot[root(w['net_b'])]=root(w['net_a'])
    expected={}
    for part in json.loads((d/'connections.json').read_text(encoding='utf-8')):
        for num,label,net,x,y in part['pins']:
            if net: expected.setdefault(net,set()).add((part['ref'],str(num)))
    combined={}
    for net,pins in actual.items(): combined.setdefault(root(net),set()).update(pins)
    assert sorted(map(sorted,combined.values()))==sorted(map(sorted,expected.values()))
    print('Verified: copper plus',len(links),'documented insulated wire links preserve every original electrical connection.')
